load('data.mat');
n = size(singvals,1);
semilogy(1:n,singvals,'b-',1:n,prjctons,'r.');