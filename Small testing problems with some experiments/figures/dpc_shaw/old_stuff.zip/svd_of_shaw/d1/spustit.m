clear;
n = 60;
tic

[A,b,x] = shaw(400);
[U,S,V] = svd(A);
toc

digs = 110;
[A2,b2,x2] = shaw_vpa(n,digs);
toc
[U2,S2,V2] = svd(A2);
toc 


b_ex = b;
b_no = randn(400,1);
b_no04 = b_no*1e-04*sqrt(b_ex'*b_ex)/sqrt(b_no'*b_no);
b_no08 = b_no*1e-08*sqrt(b_ex'*b_ex)/sqrt(b_no'*b_no);
b_no14 = b_no*1e-14*sqrt(b_ex'*b_ex)/sqrt(b_no'*b_no);
b04 = b_ex + b_no04;
b08 = b_ex + b_no08;
b14 = b_ex + b_no14;
b04 = b04/sqrt(b04'*b04);
b08 = b08/sqrt(b08'*b08);
b14 = b14/sqrt(b14'*b14);

b2 = b2/sqrt(b2'*b2);

%1:400,diag(S),'b--',

semilogy(1:n,double(diag(S2)),'k-',...
  1:400,abs(U'*b04),'g^',...
  1:400,abs(U'*b08),'bs',...
  1:400,abs(U'*b14),'ro',...
  1:n,abs(double(U2'*b2)),'k*');
  
legend('\sigma_j','|u_j^T b| for \delta_{noise} = 10^{-4}','|u_j^T b| for \delta_{noise} = 10^{-8}','|u_j^T b| for \delta_{noise} = 10^{-14}','|u_j^T b^{exact}|',4)  
xlabel('singular value number');
axis([0,400,1e-60,1e0]);  
  
singvals = double(diag(S2));
prjctons = abs(double(U2'*b2));
save('data.mat','singvals','prjctons');